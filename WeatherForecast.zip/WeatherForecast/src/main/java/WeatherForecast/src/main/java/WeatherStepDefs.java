package WeatherForecast.src.main.java;


import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;
import junit.framework.Assert;
public class WeatherStepDefs {
	
	public Properties prop = null;
	public Properties DB_Details_Prop=null;
	public String URL;
	public WebDriver driver;
	public Map<String,String> max_temp_map= new HashMap<String,String>();
	public Map<String,String> max_wind_map= new HashMap<String,String>();
	public Map<String,String> min_temp_map= new HashMap<String,String>();
	public Map<String,String> max_rainfall_map= new HashMap<String,String>();
	
	
	
//Reading file name where locators are stored and QA Environment URL	
	@Given("^locators file and URL are read$")				
    public void locators_file_and_URL_are_read(DataTable dt) throws Exception							
    {		
		this.prop = new Properties();
		Map<String,String> map=dt.asMap(String.class,String.class);
		FileReader reader = new FileReader("src//main//java//ObjectRepo//"+map.get("Objects"));
		this.prop.load(reader);
		this.URL=map.get("URL");
		
		System.out.println("This Step fetched the locater file and URL from User.");					
    }		

	//Instantiating Web browser object and Launching a browser; Navigating to URL
	@And("^User opens Chrome browser and launches the application URL$")					
    public void open_browser_and_launche_URL() throws Exception 							
    {		
       System.setProperty("webdriver.chrome.driver", "src\\main\\java\\chromedriver.exe");
       this.driver=new ChromeDriver();
       this.driver.get(URL);	
       System.out.println("This step launches browser and landing on URL");					
    }		

	// Entering input text (City_Name) in City Textbox
	@When("^User clicks on city textbox and Enters \"([^\"]*)\"$")
	public void user_clicks_on_city_textbox_and_Enters(String city_name) throws Exception {
		
		Actions action = new Actions(driver);
		this.driver.findElement(By.id(this.prop.getProperty("city_textbox_id"))).clear();
		this.driver.findElement(By.id(this.prop.getProperty("city_textbox_id"))).sendKeys(city_name);
	    action.sendKeys(Keys.ENTER).build().perform();
                
	}
	
	/*After entering city name, checking if 5 days forecast details are displayed 
	by retrieving all 5 day entries (Web elements) from UI*/
	@Then("^Weather forecast is displayed for 5 days for a given location$")
	public void Weather_forecast_displayed_for_location() throws Exception {
	
		List<WebElement> day_details= this.driver.findElements(By.xpath(this.prop.getProperty("day_entry_xpath")));
        
        int count = day_details.size();
        System.out.println("Number of days"+count);
        Assert.assertEquals("Five day weather forecast details are displayed", 5, count);
         	
		}
	/* Method is written to serve the purpose of validating error message when no/garbage city name is entered */
	@Then("^User receives error message on UI as \"([^\"]*)\"$")
	public void user_receives_error_message_on_UI(String Expected_message) throws Exception {
		this.driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		String actual_message=this.driver.findElement(By.xpath(this.prop.getProperty("error_message"))).getText();
    	
		Assert.assertEquals("Error message is displayed as expected", Expected_message, actual_message);
		
	}
	
	
	/*The method is used for the purpose of  fetching all 5 days' maximum temperature 
	 * (In UI, this detail is available as summary for each day) from UI
	 * All 5 days maximum temperature is captured as Webelements using a single xpath. 
	 * Then the temperature is retrieved using getText() selenium method inside foreach loop
	 * and the same is updated in hashmap with day. 
	 * */
	@And("^User fetches max or avg temperature for all 5 days from UI$")
	public void User_fetches_max_or_avg_temperature() throws Exception {
		
		List<WebElement> max_temp=this.driver.findElements(By.xpath(this.prop.getProperty("max_temp_xpath")));
		
		List<String> temp= new ArrayList<String>();
		for(WebElement we:max_temp)
		{
			temp.add(we.getText());
			System.out.println(we.getText());
		}
		
		for(int i=0;i<temp.size();i++)
		{
			switch(i)
			{
			case 0: max_temp_map.put("Tue20", temp.get(i));
					break;
			case 1: max_temp_map.put("Wed21", temp.get(i));
					break;		
			case 2: max_temp_map.put("Thu22", temp.get(i));
					break;	
			case 3: max_temp_map.put("Fri23", temp.get(i));
					break;	
			case 4: max_temp_map.put("Sat24", temp.get(i));
					break;	
			default: break;		
					
			}
		} 
		System.out.println(max_temp_map);
		
	}
	
	/* wriiten to perform DB validation for Temperature details: Fetched UI Data is already available public hashmap object and
	 * DB data is retrieved from Properties file and both will be compared and asserted using Assertion class method  */
	@And("^Validates the details with DB and the temperature details are displayed correctly for \"([^\"]*)\"$")
	public void Validate_the_temperature_with_DB(String city_name) throws Exception {
		
		DB_Details_Prop = new Properties();
		FileReader reader1=new FileReader("src//main//java//ObjectRepo//"+city_name+".properties");
		DB_Details_Prop.load(reader1);
		String actual;
		String expected;
		for(String temp:max_temp_map.keySet())
		{
			if(temp.contains("Tue20"))
			{
				actual=max_temp_map.get(temp);
				System.out.println("From UI,Maximum Temperature on Tue 20 is "+actual);
				expected=DB_Details_Prop.getProperty("tue20_max");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Wed21"))
			{
				actual=max_temp_map.get(temp);
				System.out.println("From UI,Maximum Temperature on Wed 21 is "+actual);
				expected=DB_Details_Prop.getProperty("wed21_max");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Thu22"))
			{
				actual=max_temp_map.get(temp);
				System.out.println("From UI,Maximum Temperature on Thu 22 is "+actual);
				expected=DB_Details_Prop.getProperty("thu22_max");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Fri23"))
			{
				actual=max_temp_map.get(temp);
				System.out.println("From UI,Maximum Temperature on Fri 23 is "+actual);
				expected=DB_Details_Prop.getProperty("fri23_max");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Sat24"))
			{
				actual=max_temp_map.get(temp);
				System.out.println("From UI,Maximum Temperature on Sat 24 is "+actual);
				expected=DB_Details_Prop.getProperty("sat24_max");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			
		}
		
	}
	
	@Given("^weather forecast is recorded already for 5 days$")
	public void Weather_forecast_recorded() throws Exception {
	
		//Creating one properties class object to work on DB Details properties files
		
	//	DB_Details_Prop=new Properties();
		System.out.println("Property files object is created");
			
		}
	

	/*The method is used for the purpose of  fetching all 5 days' maximum windspeed 
	 * (In UI, this detail is available as summary for each day) from UI
	 *  All 5 days maximum windspeed is captured as Webelements using a single xpath. 
	 * Then the windspeed is retrieved using getText() selenium method inside foreach loop
	 * and the same is updated in hashmap with day. 
	 * */
	@And("^User fetches max wind speed for all 5 days from UI$")
	public void User_fetches_max_windspeed() throws Exception {
		
		List<WebElement> max_wind=this.driver.findElements(By.xpath(this.prop.getProperty("max_wind_xpath")));
		
		List<String> temp= new ArrayList<String>();
		for(WebElement we:max_wind)
		{
			temp.add(we.getText());
			System.out.println(we.getText());
		}
		
		for(int i=0;i<temp.size();i++)
		{
			switch(i)
			{
			case 0: max_wind_map.put("Tue20", temp.get(i));
					break;
			case 1: max_wind_map.put("Wed21", temp.get(i));
					break;		
			case 2: max_wind_map.put("Thu22", temp.get(i));
					break;	
			case 3: max_wind_map.put("Fri23", temp.get(i));
					break;	
			case 4: max_wind_map.put("Sat24", temp.get(i));
					break;	
			default: break;		
					
			}
		} 
		System.out.println(max_wind_map);
		
	}
	
	/* wriiten to perform DB validation for Windspeed details: Fetched UI Data is already available public hashmap object and
	 * DB data is retrieved from Properties file and both will be compared and asserted using Assertion class method  */
	@And("^Validates the details with DB and the wind speed details are displayed correctly for \"([^\"]*)\"$")
	public void Validate_the_windspeed_with_DB(String city_name) throws Exception {
		
		Properties DB_Details_Prop_Speed = new Properties();
		FileReader reader1=new FileReader("src//main//java//ObjectRepo//"+city_name+".properties");
		DB_Details_Prop_Speed.load(reader1);
		String actual;
		String expected;
		for(String temp:max_wind_map.keySet())
		{
			if(temp.contains("Tue20"))
			{
				actual=max_wind_map.get(temp);
				System.out.println("From UI,Maximum WindSpeed on Tue 20 is "+actual);
				expected=DB_Details_Prop_Speed.getProperty("tue20_speed");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Wed21"))
			{
				actual=max_wind_map.get(temp);
				System.out.println("From UI,Maximum WindSpeed on Wed 21 is "+actual);
				expected=DB_Details_Prop_Speed.getProperty("wed21_speed");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Thu22"))
			{
				actual=max_wind_map.get(temp);
				System.out.println("From UI,Maximum WindSpeed on Thu 22 is "+actual);
				expected=DB_Details_Prop_Speed.getProperty("thu22_speed");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Fri23"))
			{
				actual=max_wind_map.get(temp);
				System.out.println("From UI,Maximum WindSpeed on Fri 23 is "+actual);
				expected=DB_Details_Prop_Speed.getProperty("fri23_speed");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Sat24"))
			{
				actual=max_wind_map.get(temp);
				System.out.println("From UI,Maximum WindSpeed on Sat 24 is "+actual);
				expected=DB_Details_Prop_Speed.getProperty("sat24_speed");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			
		}
		
	}
	

	/*The method is used for the purpose of  fetching all 5 days' minimum temperature 
	 * (In UI, this detail is available as summary for each day) from UI* All 5 days 
	 * minimum temperature is captured as Webelements using a single xpath. 
	 * Then the temperature is retrieved using getText() selenium method inside foreach loop
	 * and the same is updated in hashmap with day. 
	 * */
	@And("^User fetches min temperature for all 5 days from UI$")
	public void User_fetches_min_temperature() throws Exception {
		
		List<WebElement> min_temp=this.driver.findElements(By.xpath(this.prop.getProperty("min_temp_xpath")));
		
		List<String> temp= new ArrayList<String>();
		for(WebElement we:min_temp)
		{
			temp.add(we.getText());
			System.out.println(we.getText());
		}
		
		for(int i=0;i<temp.size();i++)
		{
			switch(i)
			{
			case 0: min_temp_map.put("Tue20", temp.get(i));
					break;
			case 1: min_temp_map.put("Wed21", temp.get(i));
					break;		
			case 2: min_temp_map.put("Thu22", temp.get(i));
					break;	
			case 3: min_temp_map.put("Fri23", temp.get(i));
					break;	
			case 4: min_temp_map.put("Sat24", temp.get(i));
					break;	
			default: break;		
					
			}
		} 
		System.out.println(min_temp_map);
		
	}
	
	/* wriiten to perform DB validation for Minimum Temperature details: Fetched UI Data is already available public hashmap object and
	 * DB data is retrieved from Properties file and both will be compared and asserted using Assertion class method  */
	@And("^Validates the details with DB and the minimum temperature details are displayed correctly for \"([^\"]*)\"$")
	public void Validate_the_min_temperature_with_DB(String city_name) throws Exception {
		
		Properties DB_Details_Prop_temp = new Properties();
		FileReader reader1=new FileReader("src//main//java//ObjectRepo//"+city_name+".properties");
		DB_Details_Prop_temp.load(reader1);
		String actual;
		String expected;
		for(String temp:min_temp_map.keySet())
		{
			if(temp.contains("Tue20"))
			{
				actual=min_temp_map.get(temp);
				System.out.println("Min temperature from UI"+ actual);
				System.out.println("From UI,minimum Temperature on Tue 20 is "+actual);
				expected=DB_Details_Prop_temp.getProperty("tue20_min");
				System.out.println("Min temperature from DB"+ expected);
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Wed21"))
			{
				actual=min_temp_map.get(temp);
				System.out.println("Min temperature from UI"+ actual);
				System.out.println("From UI,minimum Temperature on Wed 21 is "+actual);
				expected=DB_Details_Prop_temp.getProperty("wed21_min");
				System.out.println("Min temperature from DB"+ expected);
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Thu22"))
			{
				actual=min_temp_map.get(temp);
				System.out.println("Min temperature from UI"+ actual);
				System.out.println("From UI,minimum Temperature on Thu 22 is "+actual);
				expected=DB_Details_Prop_temp.getProperty("thu22_min");
				System.out.println("Min temperature from DB"+ expected);
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Fri23"))
			{
				actual=max_wind_map.get(temp);
				System.out.println("Min temperature from UI"+ actual);
				System.out.println("From UI,minimum Temperature on Fri 23 is "+actual);
				expected=DB_Details_Prop_temp.getProperty("fri23_min");
				System.out.println("Min temperature from DB"+ expected);
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Sat24"))
			{
				actual=max_wind_map.get(temp);
				System.out.println("Min temperature from UI"+ actual);
				System.out.println("From UI,minimum Temperature on Sat 24 is "+actual);
				expected=DB_Details_Prop_temp.getProperty("sat24_min");
				System.out.println("Min temperature from DB"+ expected);
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			
		}
		
	}
	

	/*The method is used for the purpose of  fetching all 5 days' maximum rainfall 
	 * (In UI, this detail is available as summary for each day) from UI
	 *  All 5 days maximum rainfall is captured as Webelements using a single xpath. 
	 * Then the rainfall is retrieved using getText() selenium method inside foreach loop
	 * and the same is updated in hashmap with day. 
	 * */
	@And("^User fetches max rainfall for all 5 days from UI$")
	public void User_fetches_max_rainfall() throws Exception {
		
		List<WebElement> max_rainfall=this.driver.findElements(By.xpath(this.prop.getProperty("max_rainfall_xpath")));
		
		List<String> temp= new ArrayList<String>();
		for(WebElement we:max_rainfall)
		{
			temp.add(we.getText());
			System.out.println(we.getText());
		}
		
		for(int i=0;i<temp.size();i++)
		{
			switch(i)
			{
			case 0: max_rainfall_map.put("Tue20", temp.get(i));
					break;
			case 1: max_rainfall_map.put("Wed21", temp.get(i));
					break;		
			case 2: max_rainfall_map.put("Thu22", temp.get(i));
					break;	
			case 3: max_rainfall_map.put("Fri23", temp.get(i));
					break;	
			case 4: max_rainfall_map.put("Sat24", temp.get(i));
					break;	
			default: break;		
					
			}
		} 
		System.out.println(max_rainfall_map);
		
	}
	
	/* wriiten to perform DB validation for Rainfall details: Fetched UI Data is already available public hashmap object and
	 * DB data is retrieved from Properties file and both will be compared and asserted using Assertion class method  */
	@And("^Validates the details with DB and the maximum rainfall details are displayed correctly for \"([^\"]*)\"$")
	public void Validate_the_max_rainfall_with_DB(String city_name) throws Exception {
		
		Properties DB_Details_Prop_rainfall = new Properties();
		FileReader reader1=new FileReader("src//main//java//ObjectRepo//"+city_name+".properties");
		DB_Details_Prop_rainfall.load(reader1);
		String actual;
		String expected;
		for(String temp:max_rainfall_map.keySet())
		{
			if(temp.contains("Tue20"))
			{
				actual=max_rainfall_map.get(temp);
				System.out.println("From UI,Maximum Rainfall on Tue 20 is "+actual);
				expected=DB_Details_Prop_rainfall.getProperty("tue20_rainfall");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Wed21"))
			{
				actual=max_rainfall_map.get(temp);
				System.out.println("From UI,Maximum Rainfall on Wed 21 is "+actual);
				expected=DB_Details_Prop_rainfall.getProperty("wed21_rainfall");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Thu22"))
			{
				actual=max_rainfall_map.get(temp);
				System.out.println("From UI,Maximum Rainfall on Thu 22 is "+actual);
				expected=DB_Details_Prop_rainfall.getProperty("thu22_rainfall");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Fri23"))
			{
				actual=max_rainfall_map.get(temp);
				System.out.println("From UI,Maximum Rainfall on Fri 23 is "+actual);
				expected=DB_Details_Prop_rainfall.getProperty("fri23_rainfall");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			else if(temp.contains("Sat24"))
			{
				actual=max_rainfall_map.get(temp);
				System.out.println("From UI,Maximum Rainfall on Sat 24 is "+actual);
				expected=DB_Details_Prop_rainfall.getProperty("sat24_rainfall");
				if(actual.contains(expected))
					Assert.assertTrue("Values are mathcing",true);
			}
			
		}
		
	}
	
	/*Inside this method, code is written to click on day to show 3 hourly data
	 * Here replace() method of built-in String class is used to change the day in xpath dynamically
	 *  */
	@When("^User clicks on \"([^\"]*)\" Entry$")
	public void User_Clicks_On_Day(String Day) throws Exception {
		
		String XPATH= new String(this.prop.getProperty("Day_xpath"));
		System.out.println("The Day is------------->"+Day);
		XPATH=XPATH.replace("$variable$", Day);
		System.out.println("Modified Xpath is-----> "+XPATH);
		this.driver.findElement(By.xpath(XPATH)).click();
			
	}
	
	/* This method is written to check whether 3 hourly forecast for all cities are shown when user clicks on day
	 * Here replace() method of built-in String class is used to change the day in xpath dynamically
	 * Further more, this method validates whether the displayed 3 hourly data are having really 
	 * a 3 hours difference as per requirement or not
	 *  */
	@Then("^Three hourly forecasts are visible to user for \"([^\"]*)\"$")
	public void ThreeHourly_forecasts_are_visible(String Day) throws Exception {
		
		String XPATH=this.prop.getProperty("Hour_xpath");
		XPATH=XPATH.replace("$variable$", Day);
		List<WebElement> webList=this.driver.findElements(By.xpath(XPATH));
		List<String> list =new ArrayList<String>();
		
		for(WebElement we:webList)
		{
			list.add(we.getText());
		}
		
		for(int i=0;i<list.size();i++)
		{
			if((i+1)!=list.size())
			{
				if((Integer.parseInt(list.get(i+1)))
						-Integer.parseInt(list.get(i))==300)
				{
					System.out.println("For"+ Day+" Day, the forecast is captured in 3 hour difference as per requirement");
									}
					
			}
		}
			
	}
	
	/* This method is written to check whether 3 hourly forecast for all cities are hidden when user clicks on day again
	 * Here replace() method of built-in String class is used to change the day in xpath dynamically
	 * Further more, this method validates whether the displayed 3 hourly data are not visible on the UI as per requirement or not
	 * using isDisplayed() method of WebElement class
	 *  */
	@Then("^Three hourly forecasts are hidden to user for \"([^\"]*)\"$")
	public void ThreeHourly_forecasts_are_hidden(String Day) throws Exception {
		
		String XPATH=this.prop.getProperty("Hour_xpath");
		XPATH=XPATH.replace("$variable$", Day);
		List<WebElement> webList=this.driver.findElements(By.xpath(XPATH));
		
		for(WebElement we: webList)
		{
			if(!we.isDisplayed())
			{
				System.out.println("Hourly forecast is hidden");
			}
		}

	}
		
    /* This method closes webdriver after each scenario is completed; @After hook is used 
     * because we have written our web driver initiation steps into background hooks;
     * if web driver initialization is written part of scenario, we can have close driver also as part of scenario.  */
	@After
    public void close_driver()
    {
    	this.driver.close();
    }

}
